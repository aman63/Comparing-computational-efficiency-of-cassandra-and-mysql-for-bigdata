/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package final2;

import java.sql.ResultSet;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
/**
 *
 * @author User
 */
public class FINAL2 {
   static String s1,s2,s3,s4,s5;
      
        static int ids,userids,postids,scores;
  public static void main(String args[])
  {try{
       DBConnect dbc=new DBConnect("localhost","test2","sa","123", "sqlserver");
         
                for(int j=10;j<=294;j++){
          
            String S="Comments-"+String.valueOf(j)+".xml";
            File xmlFile = new File(S);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = (Document) dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("row");
            int a=0;
            for(int i=0;i<nList.getLength();i++){
                Node p=nList.item(i);
                if(p.getNodeType()==Node.ELEMENT_NODE){
                    Element yy=(Element) p;
                    s1=yy.getAttribute("Id");
                    System.out.println(s1);
                    ids=Integer.parseInt(s1);
                   s2=yy.getAttribute("PostId");
                    System.out.println(s2);
                     postids=Integer.parseInt(s2);
                    s3=yy.getAttribute("Score");
                    System.out.println(s3);
                      scores=Integer.parseInt(s3);
                    s4=yy.getAttribute("Text");
                     s4=s4.replaceAll("-","");
                     s4=s4.replaceAll("'","");
                     s4=s4.replaceAll("!", "");
                       
                    System.out.println(s4);
                    s5=yy.getAttribute("CreationDate");
                    System.out.println(s5);
                    String s6=yy.getAttribute("UserId");
                    System.out.println(s6);
                     userids=Integer.parseInt(s6);
                 

                    dbc.updateDB("insert into data(Id,PostId,Score,Comment,CreationDate) values("+ids+","+postids+","
                            +scores+",'"+s4+"','"+s5+"');");
                    System.out.println("now reading file no"+j+"\n");
                }
            }
            System.out.println("completed\n\n\n\n "+j);
        }
       // }*/
     }catch(Exception e){}
        
 
  }
}

